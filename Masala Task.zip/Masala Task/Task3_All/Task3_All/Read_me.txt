----Read Me -----


First :
  Eclipse IDE - Java Langauge 
  this task is based on POM design Pattern so you will run it from testing.xml as (Test NG)
  steps :
   precondition --- zip libs folder contain all Libs as External by right click on project press properties, open Java Build Path then Libraries tab , add external libraries
   open testing.xml file then right click then Run As (testng suite)


second :
   Adds folder contain below items :
   excel sheet for TestData (DDF)(using poi libs)(DataProvider is commented)(Parallel group is commented)
   excel sheet for TestResult
   Chrome Driver
   
Third : 
   ScreenShotsResults folder may contain some pics (Kindly Check)
fourth:

 We have Test Pacage and have below four TestNg classes each class have Task1 , Task2 ,Task3,Task4 sorted 

   Tests.TestCas1Test
   Tests.TestCase2Test
   Tests.TestCase3Test
   Tests.TestCase4Test
