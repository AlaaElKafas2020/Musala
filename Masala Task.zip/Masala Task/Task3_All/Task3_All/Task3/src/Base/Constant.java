package Base;

public class Constant
{
	//public static final String Path_TestData = ".\\Adds\\";

   public static final String  File_TestData = ".\\Adds\\TestData.xlsx";
   public static final String  File_TestResult = ".\\Adds\\TestResult.xls";
		   //".\\Adds\\TestResult.xls";
}
