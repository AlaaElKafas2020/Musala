package Base;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Cell;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
 
public class ExcelUtil
{
	static int rowcount=0;
	
	
	public static void WriteInExcel(String Value) throws IOException

	{
		  try {
			  // This block of code for saving time of writing
			  java.util.Date date = new java.util.Date();
			  //end saving time
			    // begin to write in Excel sheet
			  FileInputStream file = new FileInputStream(new File(Constant.File_TestResult));
			  Workbook workbook = WorkbookFactory.create(file);
			  Sheet  sheet = workbook.getSheetAt(0);
			  Row row = sheet.createRow(sheet.getPhysicalNumberOfRows());
	            row.createCell(0).setCellValue(Value+ "   TimeStampOfTransactionIs:   "+date);
			 
			  file.close();
			 
			  FileOutputStream outFile =new FileOutputStream(new File(Constant.File_TestResult));
			  workbook.write(outFile);
			  outFile.close();
			 
		 }
		 catch (Exception fe) {
			 System.out.println(fe.getMessage());
			  fe.printStackTrace();
		 } 
		
	  }

	public static String ReadFromExcel(int Row,int Cell) throws IOException, InvalidFormatException{
	FileInputStream fis=new FileInputStream(Constant.File_TestData);
	Workbook wb=WorkbookFactory.create(fis);
	Sheet sh=wb.getSheet("Sheet1");
	Row row=sh.getRow(Row);
	Cell cell=row.getCell(Cell);
	String cellval=cell.getStringCellValue();
	System.err.println(cellval);
	return cellval;
	}



	}