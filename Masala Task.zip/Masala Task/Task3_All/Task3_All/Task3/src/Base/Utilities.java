package Base;
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class Utilities 
{
	   public void takeScreenshot(WebDriver driver,String FileName) throws Exception {
		   String screen_shot_path =".\\ScreenShotsResults\\"+FileName+".png";
	        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(scrFile, new File(screen_shot_path));
	        Reporter.log("<td><a href='" + screen_shot_path
                    + "'><img src='" + screen_shot_path
                    + "' height='100' width='100' /></a></td>");
	        }
	   public void ExtendReport(String string1)
	   {
		   Reporter.log(string1,true);
	   }
}



