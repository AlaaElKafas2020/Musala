package Pages;


import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class TestCas2Page {
	private WebDriver driver;
    private By Company = By.xpath("//*[@id=\"menu-main-nav-1\"]/li[1]/a");
    private By LeaderShip = By.xpath("//*[@id=\"content\"]/div[2]/section[3]/div/h2");
    private By FaceBookLink=By.xpath("/html/body/footer/div/div/a[4]");
    private By Logo=By.xpath("/html/body/div[1]/div[3]/div[1]/div/div/div[1]/div/div/div[1]/div/div/div/a");
    
	public TestCas2Page(WebDriver driver) {
	
	this.driver=driver;
	}
	public void VerifyFacebookImage()
	{	
        WebElement Companyelement = driver.findElement(Company);
		Companyelement.click();
		new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/company/"));
		System.out.println("Current URL is: "+driver.getCurrentUrl());
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		//check LeaderShip is existed 
		WebElement LeaderShipelement = driver.findElement(LeaderShip);
		if(LeaderShipelement.isDisplayed()){
			System.out.println("LeaderShip is Visible");
			}
		else{
			System.out.println("LeaderShip is InVisible");
			Assert.fail("LeaderShip is InVisible ");
			}
		//Click on facebook icon
		WebElement FaceBookLinkelement = driver.findElement(FaceBookLink);
		FaceBookLinkelement.click();
		 // store window handle ids
	      ArrayList<String> w = new ArrayList<String>(driver.getWindowHandles());
	      //switch to open tab
	      driver.switchTo().window(w.get(1));
	      System.out.println("FaceBook Tab is opened: " + driver.getTitle());
	      
		  //Assert  logo
		 
		  WebDriverWait wait = new WebDriverWait(driver,15);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(Logo));
		  WebElement logoele = driver.findElement(Logo);
		  if(logoele.isDisplayed()==true){
			  System.out.println("Image is present");
		  }else{
			  System.out.println("Image is not present");
		  }
	}
	
}
