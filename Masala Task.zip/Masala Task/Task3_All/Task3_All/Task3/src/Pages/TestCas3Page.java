package Pages;
import java.util.Iterator;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.Constant;



public class TestCas3Page {
	private WebDriver driver;
    private By Careers = By.xpath("//*[@id=\"menu-main-nav-1\"]/li[5]/a");
    private By CheckPosButton=By.xpath("//*[@id=\"content\"]/div[1]/div/div[1]/div/section/div/a/button");
    private By LocationList= By.id("get_location");
	private By  description= By.xpath("//*[@id=\"post-1501\"]/div/div[2]/div[1]/div[1]/div[1]/div[2]/h2");
	private By  Requirements=By.xpath("//*[@id=\"post-1501\"]/div/div[2]/div[1]/div[1]/div[2]/div[2]/h2");
	private By  Responsibilities= By.xpath("//*[@id=\"post-1501\"]/div/div[2]/div[1]/div[2]/div[1]/div[2]/h2");
	private By  What_we_offer= By.xpath("//*[@id=\"post-1501\"]/div/div[2]/div[1]/div[2]/div[2]/div[2]/h2");
	private By ApplyButton= By.xpath("//*[@id=\"post-1501\"]/div/div[2]/div[2]/a/input");
	private By Name = By.name("your-name");
	private By Email = By.name("your-email");
	private By Mobile = By.name("mobile-number");
	private By uploadtextfield= By.name("uploadtextfield");
	private By SendButton= By.xpath("//*[@id=\"wpcf7-f880-o1\"]/form/div[3]/p/input");
	private By ErrorAlert= By.xpath("//*[@id=\"wpcf7-f880-o1\"]/form/div[4]/div/div");
	
	public TestCas3Page(WebDriver driver) {
	
	this.driver=driver;
	
	}
	public void VerifyPositionQAEngineer(String Location)
	{	
        WebElement Careerselement = driver.findElement(Careers);
        Careerselement.click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/careers/"));
		System.out.println("Current URL is: "+driver.getCurrentUrl());
        WebElement CheckPosButtonelement = driver.findElement(CheckPosButton);
        CheckPosButtonelement.click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/careers/join-us/"));
		System.out.println("Current URL is: "+driver.getCurrentUrl());
		// select Sofa from drop down
		Select dropdown = new Select(driver.findElement(LocationList));
		dropdown.selectByVisibleText(Location);
		System.err.println(Location);
		//Loop on all QA postions
		//List<WebElement> JobsList = driver.findElements(AllPos);
		WebElement QAEngineerjobTitle= driver.findElement(By.xpath("//h2[@data-alt='Experienced Automation QA Engineer']"));
		QAEngineerjobTitle.click();
		new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/job/experienced-automation-qa-engineer/"));
	    System.out.println("Current URL is: "+driver.getCurrentUrl());
	    Assert.assertTrue(driver.findElement(description).isDisplayed());
	    Assert.assertTrue(driver.findElement(Requirements).isDisplayed());
	    Assert.assertTrue(driver.findElement(Responsibilities).isDisplayed());
	    Assert.assertTrue(driver.findElement(What_we_offer).isDisplayed());
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	    WebElement QApplyButton_ele= driver.findElement(ApplyButton);
	    QApplyButton_ele.click();
		//switch to child popup
		//String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); // get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); 
		// switch to popup window
		String TestValue="test@1";
		WebElement Nameelement = driver.findElement(Name);
		Nameelement.sendKeys(TestValue);
		WebElement Emailelement = driver.findElement(Email);
		Emailelement.sendKeys(TestValue);
		WebElement Mobile_element = driver.findElement(Mobile);
		Mobile_element.sendKeys("01001234556");
		WebElement uploadtextfield_ele = driver.findElement(uploadtextfield);
		uploadtextfield_ele.sendKeys(Constant.File_TestResult);
		WebElement SendButton_ele= driver.findElement(SendButton);
		SendButton_ele.click();
		WebElement ErrorAlert_ele= driver.findElement(ErrorAlert);
		String Expected ="One or more fields have an error. Please check and try again.";
		String Actual= ErrorAlert_ele.getText();
		Assert.assertTrue(Expected.equals(Actual));
		
	}
	

}