package Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TestCas4Page {
	private WebDriver driver;
    private By Careers = By.xpath("//*[@id=\"menu-main-nav-1\"]/li[5]/a");
    private By CheckPosButton=By.xpath("//*[@id=\"content\"]/div[1]/div/div[1]/div/section/div/a/button");
    private By LocationList= By.id("get_location");
    //private By AllPos=By.xpath("//div[@class='card-container']");
    
	public TestCas4Page(WebDriver driver) {
	
	this.driver=driver;
	}
	public void VerifyPositions(String Location)
	{	
        WebElement Careerselement = driver.findElement(Careers);
        Careerselement.click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/careers/"));
		System.out.println("Current URL is: "+driver.getCurrentUrl());
        WebElement CheckPosButtonelement = driver.findElement(CheckPosButton);
        CheckPosButtonelement.click();
        new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe("https://www.musala.com/careers/join-us/"));
		System.out.println("Current URL is: "+driver.getCurrentUrl());
		// select Sofa from drop down
		Select dropdown = new Select(driver.findElement(LocationList));
		dropdown.selectByVisibleText(Location);
		System.err.println(Location);
		//Loop on all postions
		//List<WebElement> JobsList = driver.findElements(AllPos);
		List<WebElement> jobTitle= driver.findElements(By.xpath("//h2[@class='card-jobsHot__title']"));
		List<WebElement> jobUrl=  driver.findElements(By.xpath("//a[@class='card-jobsHot__link']"));
		int temp = jobTitle.size();
		for(int i=0; i<temp; i++) {
		     // Print the job
		    String Title= jobTitle.get(i).getText();
		    System.out.println("Postion: "+Title);
		    String url =  jobUrl.get(i).getAttribute("href");
		    System.out.println("More Info: "+url);
		    System.out.println("\n");
            }
	
	}
	

}