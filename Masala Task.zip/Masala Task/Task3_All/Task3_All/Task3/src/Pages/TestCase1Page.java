package Pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Base.Utilities;
import Base.ExcelUtil;

public class TestCase1Page {
	private WebDriver driver;
    private By ContactUs = By.xpath("/html/body/main/section[2]/div/div/div/a[1]/button");
    private By Name = By.name("your-name");
    private By Email = By.name("your-email");
    private By Subject = By.name("your-subject");
    private By yourMessage = By.name("your-message");
    private By SubmitButton = By.xpath("//*[@id=\"wpcf7-f875-o1\"]/form/div[2]/p/input");
    private By ErrorMessagespan = By.xpath("//*[@id=\"wpcf7-f875-o1\"]/form/p[2]/span/span");
    String expected_txt = "The e-mail address entered is invalid.";
    
	public TestCase1Page(WebDriver driver) {
	this.driver=driver;
	}
	public void ContactUsTestCase(String TestValue)
	{	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		WebElement ContactUselement = driver.findElement(ContactUs);
		ContactUselement.click();
		//switch to child popup
		String parentWindowHandler = driver.getWindowHandle(); // Store your parent window
		String subWindowHandler = null;

		Set<String> handles = driver.getWindowHandles(); // get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); // switch to popup window

		// Now you are in the popup window, perform necessary actions here
		WebElement Nameelement = driver.findElement(Name);
		Nameelement.sendKeys(TestValue);
		WebElement Emailelement = driver.findElement(Email);
		Emailelement.sendKeys(TestValue);
		WebElement Subjectelement = driver.findElement(Subject);
		Subjectelement.sendKeys(TestValue);
		WebElement yourMessageelement = driver.findElement(yourMessage);
		yourMessageelement.sendKeys(TestValue);
		WebElement SubmitButtonelement = driver.findElement(SubmitButton);
		SubmitButtonelement.click();
		//To wait for element visible
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(ErrorMessagespan));
		WebElement ErrorMessagespan_elm=driver.findElement(ErrorMessagespan);
		String actual_Errortxt = ErrorMessagespan_elm.getText().toString();
		Assert.assertEquals( actual_Errortxt.toLowerCase(), expected_txt.toLowerCase());
		  try {
		
		    Utilities u= new Utilities();
			u.takeScreenshot(driver,"Screenshot2");
		    ExcelUtil.WriteInExcel("Test User clicked Contact us ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// switch back to parent window
		  driver.switchTo().window(parentWindowHandler);  
	}
}
