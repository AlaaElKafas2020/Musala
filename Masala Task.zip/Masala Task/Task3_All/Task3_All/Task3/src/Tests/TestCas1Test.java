package Tests;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//import Base.Constant;
//import Base.DPclasss;
import Base.ExcelUtil;
import Base.TestBaseSetup;
import Pages.TestCase1Page;


public class TestCas1Test extends TestBaseSetup {
	private WebDriver driver;
    private String TestVal="T@test";
	
	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
	
	//@Test(dataProvider="InvalidEmail")
	@Test
	public void InvalidContactus() {
		System.out.println("testcase1...");
		try {
			TestVal= ExcelUtil.ReadFromExcel(3,0);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		TestCase1Page TestCase1ob= new TestCase1Page(driver);
		TestCase1ob.ContactUsTestCase(TestVal);
		
		
	}
	/* @DataProvider
	    public Object[][] InvalidEmail () throws Exception{

	         Object[][] testObjArray =DPclasss.getTableArray(Constant.File_TestData,"Sheet1");
	         return (testObjArray);

			}
	*/

	    @AfterMethod

	    public void afterMethod() {

	  	   // driver.quit();

	    	}
	
}


