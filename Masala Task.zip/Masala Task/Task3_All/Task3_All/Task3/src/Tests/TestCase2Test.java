package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBaseSetup;
import Pages.TestCas2Page; 

public class TestCase2Test extends TestBaseSetup {
	private WebDriver driver;
	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
  //@Test(groups = { "ParallelRuns-Group" })
	@Test
  public void VerifyFaceBookLinkTest()
  {
	  TestCas2Page T2Ob= new TestCas2Page(driver);
	  T2Ob.VerifyFacebookImage();
  }
}
