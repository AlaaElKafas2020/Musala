package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBaseSetup;
import Pages.TestCas4Page; 

public class TestCase4Test extends TestBaseSetup {
	private WebDriver driver;
	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
  @Test
  public void VerifyPostiomsTest()
  {
	  TestCas4Page T4Ob= new TestCas4Page(driver);
	  T4Ob.VerifyPositions("Sofia");
  }
}
